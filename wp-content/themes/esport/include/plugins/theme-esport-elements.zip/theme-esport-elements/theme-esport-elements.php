<?php
/**
* Plugin Name: eSport Theme: Elements
* Plugin URI: http://themeforest.net/user/gloriathemes
* Description: eSport elements plugin.
* Version: 1.0
* Author: Gloria Themes
* Author URI: http://gloriathemes.com/
*/

/*------------- USER PROFILES START -------------*/
	/*------------- USER PROFILES - SOCIAL MEDIA START -------------*/
	function esport_user_profile_social_media( $user_profile_create_fields ) {
		$user_profile_create_fields['facebook'] = esc_html__( 'Facebook', 'esport' );
		$user_profile_create_fields['googleplus'] = esc_html__( 'Google+', 'esport' );
		$user_profile_create_fields['instagram'] = esc_html__( 'Instagram', 'esport' );
		$user_profile_create_fields['linkedin'] = esc_html__( 'LinkedIn', 'esport' );
		$user_profile_create_fields['vine'] = esc_html__( 'Vine', 'esport' );
		$user_profile_create_fields['twitter'] = esc_html__( 'Twitter', 'esport' );
		$user_profile_create_fields['pinterest'] = esc_html__( 'Pinterest', 'esport' );
		$user_profile_create_fields['youtube'] = esc_html__( 'YouTube', 'esport' );
		$user_profile_create_fields['behance'] = esc_html__( 'Behance', 'esport' );
		$user_profile_create_fields['deviantart'] = esc_html__( 'DeviantArt', 'esport' );
		$user_profile_create_fields['digg'] = esc_html__( 'Digg', 'esport' );
		$user_profile_create_fields['dribbble'] = esc_html__( 'Dribbble', 'esport' );
		$user_profile_create_fields['flickr'] = esc_html__( 'Flickr', 'esport' );
		$user_profile_create_fields['github'] = esc_html__( 'GitHub', 'esport' );
		$user_profile_create_fields['lastfm'] = esc_html__( 'Last.fm', 'esport' );
		$user_profile_create_fields['reddit'] = esc_html__( 'Reddit', 'esport' );
		$user_profile_create_fields['soundcloud'] = esc_html__( 'SoundCloud', 'esport' );
		$user_profile_create_fields['tumblr'] = esc_html__( 'Tumblr', 'esport' );
		$user_profile_create_fields['vimeo'] = esc_html__( 'Vimeo', 'esport' );
		$user_profile_create_fields['vk'] = esc_html__( 'VK', 'esport' );
		$user_profile_create_fields['medium'] = esc_html__( 'Medium', 'esport' );
		return $user_profile_create_fields;
	}
	add_filter( 'user_contactmethods', 'esport_user_profile_social_media', 10, 1 );
	/*------------- USER PROFILES - SOCIAL MEDIA END -------------*/
/*------------- USER PROFILES END -------------*/


/*------------- COMMENTS START -------------*/
	/*------------- COMMENT LIST START -------------*/
	function esport_comment( $comment, $args, $depth ) {
		$GLOBALS['comment'] = $comment;
		extract($args, EXTR_SKIP);

		if ( 'div' == $args['style'] ) {
			$tag = 'div';
			$add_below = 'comment';
		} else {
			$tag = 'li';
			$add_below = 'div-comment';
		}
	?>
		<<?php echo esc_attr( $tag ) ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ) ?> id="comment-<?php comment_ID() ?>">
		
		<?php if ( 'div' != $args['style'] ) { ?>
			<div id="div-comment-<?php comment_ID() ?>" class="comment-body">
		<?php } ?>
			<div class="comment-author vcard">
				<?php
					$user = get_user_by( 'email', $comment->comment_author_email );
				?>
				<?php if ( $args['avatar_size'] != 0 ) { echo get_avatar( $comment, $args['avatar_size'] ); } ?>
				<?php $allowed_html = array ( 'span' => array() ); printf( wp_kses( '<cite class="fn">%s</cite>', 'esport' ), get_comment_author() ); ?>

				<div class="comment-meta commentmetadata"><a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>">
					<?php printf( esc_html__( '%1$s', 'esport' ), get_comment_date(),  get_comment_time() ); ?></a>
				</div>

				<div class="reply">
					<?php comment_reply_link( array_merge( $args, array( 'add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
					<?php edit_comment_link( '<i class="fa fa-pencil" aria-hidden="true"></i>' . esc_html__( 'Edit', 'esport' ), '  ', '' ); ?>
				</div>
			</div>
			
			<?php if ( $comment->comment_approved == '0' ) { ?>
				<em class="comment-awaiting-moderation"><?php echo esc_html__( 'Your comment is awaiting moderation.', 'esport' ); ?></em>
			<?php } ?>

			<?php comment_text(); ?>

		<?php if ( 'div' != $args['style'] ) { ?>
			</div>
		<?php } ?>
	<?php
	}
	/*------------- COMMENT LIST END -------------*/

	/*------------- COMMENT TO TOP START -------------*/
	function esport_move_comment_field_to_bottom( $fields ) {
		$comment_field = $fields['comment'];
		unset( $fields['comment'] );
		$fields['comment'] = $comment_field;
		return $fields;
	}
	add_filter( 'comment_form_fields', 'esport_move_comment_field_to_bottom' );
	/*------------- COMMENT TO TOP END -------------*/
/*------------- COMMENTS END -------------*/

/*------------- POST TYPES START -------------*/
	/*--------------- PLAYERS START ---------------*/
	if ( ! function_exists('esport_players') ) {
		function esport_players() {
			$labels = array(
				'name' => _x( 'Players', 'Players General Name', 'esport' ),
				'singular_name' => _x( 'Player', 'Players Singular Name', 'esport' ),
				'menu_name' => esc_html__( 'Players', 'esport' ),
				'parent_item_colon' => esc_html__( 'Parent Player:', 'esport' ),
				'all_items' => esc_html__( 'All Players', 'esport' ),
				'view_item' => esc_html__( 'View Player', 'esport' ),
				'add_new_item' => esc_html__( 'Add New Player Item', 'esport' ),
				'add_new' => esc_html__( 'Add New Player', 'esport' ),
				'edit_item' => esc_html__( 'Edit Player', 'esport' ),
				'update_item' => esc_html__( 'Update Player', 'esport' ),
				'search_items' => esc_html__( 'Search Player', 'esport' ),
				'not_found' => esc_html__( 'Not Player Found', 'esport' ),
				'not_found_in_trash' => esc_html__( 'Not Player Found in Trash', 'esport' ),
			);
			$args = array(
				'label' => esc_html__( 'Players', 'esport' ),
				'description' => esc_html__( 'Player post type description.', 'esport' ),
				'labels' => $labels,
				'supports' => array( 'title', 'comments', 'author', 'excerpt', 'thumbnail', 'revisions', 'editor' ),
				'hierarchical' => false,
				'public' => true,
				'show_ui' => true,
				'show_in_menu' => true,
				'show_in_nav_menus' => true,
				'show_in_admin_bar' => true,
				'menu_position' => 20,
				'menu_icon' => 'dashicons-groups',
				'can_export' => true,
				'has_archive' => true,
				'exclude_from_search' => false,
				'publicly_queryable' => true,
				'capability_type' => 'post',
			);
			register_post_type( 'player', $args );
		}
		add_action( 'init', 'esport_players', 0 );
	}
	/*--------------- PLAYERS END ---------------*/

	/*--------------- TEAM START ---------------*/
	if ( ! function_exists('esport_team') ) {
		function esport_team() {
			$labels = array(
				'name' => _x( 'Team', 'Team General Name', 'esport' ),
				'singular_name' => _x( 'Member', 'Team Singular Name', 'esport' ),
				'menu_name' => esc_html__( 'Team', 'esport' ),
				'parent_item_colon' => esc_html__( 'Parent Member:', 'esport' ),
				'all_items' => esc_html__( 'All Team', 'esport' ),
				'view_item' => esc_html__( 'View Member', 'esport' ),
				'add_new_item' => esc_html__( 'Add New Member Item', 'esport' ),
				'add_new' => esc_html__( 'Add New Member', 'esport' ),
				'edit_item' => esc_html__( 'Edit Member', 'esport' ),
				'update_item' => esc_html__( 'Update Member', 'esport' ),
				'search_items' => esc_html__( 'Search Member', 'esport' ),
				'not_found' => esc_html__( 'Not Member Found', 'esport' ),
				'not_found_in_trash' => esc_html__( 'Not Member Found in Trash', 'esport' ),
			);
			$args = array(
				'label' => esc_html__( 'Team', 'esport' ),
				'description' => esc_html__( 'Member post type description.', 'esport' ),
				'labels' => $labels,
				'supports' => array( 'title', 'comments', 'author', 'excerpt', 'thumbnail', 'revisions', 'editor' ),
				'hierarchical' => false,
				'public' => true,
				'show_ui' => true,
				'show_in_menu' => true,
				'show_in_nav_menus' => true,
				'show_in_admin_bar' => true,
				'menu_position' => 20,
				'menu_icon' => 'dashicons-admin-users',
				'can_export' => true,
				'has_archive' => true,
				'exclude_from_search' => false,
				'publicly_queryable' => true,
				'capability_type' => 'post',
			);
			register_post_type( 'team', $args );
		}
		add_action( 'init', 'esport_team', 0 );
	}
	/*--------------- TEAM END ---------------*/

	/*--------------- FIXTURES START ---------------*/
	if ( ! function_exists('esport_fixtures') ) {
		function esport_fixtures() {
			$labels = array(
				'name' => _x( 'Fixtures', 'Fixtures General Name', 'esport' ),
				'singular_name' => _x( 'Match', 'Fixtures Singular Name', 'esport' ),
				'menu_name' => esc_html__( 'Fixtures', 'esport' ),
				'parent_item_colon' => esc_html__( 'Parent Match:', 'esport' ),
				'all_items' => esc_html__( 'All Fixtures', 'esport' ),
				'view_item' => esc_html__( 'View Match', 'esport' ),
				'add_new_item' => esc_html__( 'Add New Match Item', 'esport' ),
				'add_new' => esc_html__( 'Add New Match', 'esport' ),
				'edit_item' => esc_html__( 'Edit Match', 'esport' ),
				'update_item' => esc_html__( 'Update Match', 'esport' ),
				'search_items' => esc_html__( 'Search Match', 'esport' ),
				'not_found' => esc_html__( 'Not Match Found', 'esport' ),
				'not_found_in_trash' => esc_html__( 'Not Match Found in Trash', 'esport' ),
			);
			$args = array(
				'label' => esc_html__( 'Fixtures', 'esport' ),
				'description' => esc_html__( 'Match post type description.', 'esport' ),
				'labels' => $labels,
				'supports' => array( 'title', 'comments', 'author', 'excerpt', 'thumbnail', 'revisions', 'editor' ),
				'hierarchical' => false,
				'public' => true,
				'show_ui' => true,
				'show_in_menu' => true,
				'show_in_nav_menus' => true,
				'show_in_admin_bar' => true,
				'menu_position' => 20,
				'menu_icon' => 'dashicons-calendar-alt',
				'can_export' => true,
				'has_archive' => true,
				'exclude_from_search' => false,
				'publicly_queryable' => true,
				'capability_type' => 'post',
			);
			register_post_type( 'fixtures', $args );
		} 
		add_action( 'init', 'esport_fixtures', 0 );
	}
	/*--------------- FIXTURES END ---------------*/
/*------------- POST TYPES END -------------*/

/*--------------- TAXONOMY START ---------------*/
	/*--------------- GAMES START ---------------*/
	if ( ! function_exists( 'game' ) ) {
		function game() {
			$labels = array(
				'name' => _x( 'Games', 'Games General Name', 'esport' ),
				'singular_name' => _x( 'Games', 'Games Singular Name', 'esport' ),
				'menu_name' => esc_html__( 'Games', 'esport' ),
				'all_items' => esc_html__( 'All Games', 'esport' ),
				'parent_item' => esc_html__( 'Parent Game', 'esport' ),
				'parent_item_colon' => esc_html__( 'Parent Game:', 'esport' ),
				'new_item_name' => esc_html__( 'New Game Name', 'esport' ),
				'add_new_item' => esc_html__( 'Add New Game', 'esport' ),
				'edit_item' => esc_html__( 'Edit Game', 'esport' ),
				'view_item' => esc_html__( 'View Game', 'esport' ),
				'update_item' => esc_html__( 'Update Game', 'esport' ),
				'separate_items_with_commas' => esc_html__( 'Separate games with commas', 'esport' ),
				'search_items' => esc_html__( 'Search Games', 'esport' ),
				'add_or_remove_items' => esc_html__( 'Add or remove games', 'esport' ),
				'choose_from_most_used' => esc_html__( 'Choose from the most used games', 'esport' ),
				'not_found' => esc_html__( 'Not Found', 'esport' ),
			);
			$args = array(
				'labels' => $labels,
				'hierarchical' => true,
				'public' => true,
				'show_ui' => true,
				'show_admin_column' => false,
				'show_in_nav_menus' => true,
				'show_tagcloud' => true,
			);
			register_taxonomy( 'game', array( 'fixtures', 'player' ), $args );

		}
		add_action( 'init', 'game', 0 );
	}
	/*--------------- GAMES END ---------------*/

	/*--------------- CLUBS START ---------------*/
	if ( ! function_exists( 'club' ) ) {
		function club() {
			$labels = array(
				'name' => _x( 'Clubs', 'Clubs General Name', 'esport' ),
				'singular_name' => _x( 'Clubs', 'Clubs Singular Name', 'esport' ),
				'menu_name' => esc_html__( 'Clubs', 'esport' ),
				'all_items' => esc_html__( 'All Clubs', 'esport' ),
				'parent_item' => esc_html__( 'Parent Club', 'esport' ),
				'parent_item_colon' => esc_html__( 'Parent Club:', 'esport' ),
				'new_item_name' => esc_html__( 'New Club Name', 'esport' ),
				'add_new_item' => esc_html__( 'Add New Club', 'esport' ),
				'edit_item' => esc_html__( 'Edit Club', 'esport' ),
				'view_item' => esc_html__( 'View Club', 'esport' ),
				'update_item' => esc_html__( 'Update Club', 'esport' ),
				'separate_items_with_commas' => esc_html__( 'Separate clubs with commas', 'esport' ),
				'search_items' => esc_html__( 'Search Clubs', 'esport' ),
				'add_or_remove_items' => esc_html__( 'Add or remove clubs', 'esport' ),
				'choose_from_most_used' => esc_html__( 'Choose from the most used clubs', 'esport' ),
				'not_found' => esc_html__( 'Not Found', 'esport' ),
			);
			$args = array(
				'labels' => $labels,
				'hierarchical' => true,
				'public' => true,
				'show_ui' => true,
				'show_admin_column' => false,
				'show_in_nav_menus' => true,
				'show_tagcloud' => true,
			);
			register_taxonomy( 'club', array( 'fixtures' ), $args );

		}
		add_action( 'init', 'club', 0 );
	}
	/*--------------- CLUBS END ---------------*/
	
	/*--------------- FIXTURE CATEGORIES START ---------------*/
	if ( ! function_exists( 'fixturescat' ) ) {
		function fixturescat() {
			$labels = array(
				'name' => _x( 'Fixtures Categories', 'Fixtures Categories General Name', 'esport' ),
				'singular_name' => _x( 'Fixtures Categories', 'Fixtures Categories Singular Name', 'esport' ),
				'menu_name' => esc_html__( 'Fixtures Categories', 'esport' ),
				'all_items' => esc_html__( 'All Fixtures Categories', 'esport' ),
				'parent_item' => esc_html__( 'Parent Fixtures Category', 'esport' ),
				'parent_item_colon' => esc_html__( 'Parent Fixtures Category:', 'esport' ),
				'new_item_name' => esc_html__( 'New Fixtures Category Name', 'esport' ),
				'add_new_item' => esc_html__( 'Add New Fixtures Category', 'esport' ),
				'edit_item' => esc_html__( 'Edit Fixtures Category', 'esport' ),
				'view_item' => esc_html__( 'View Fixtures Category', 'esport' ),
				'update_item' => esc_html__( 'Update Fixtures Category', 'esport' ),
				'separate_items_with_commas' => esc_html__( 'Separate fixtures categories with commas', 'esport' ),
				'search_items' => esc_html__( 'Search Fixtures Categories', 'esport' ),
				'add_or_remove_items' => esc_html__( 'Add or remove fixtures categories', 'esport' ),
				'choose_from_most_used' => esc_html__( 'Choose from the most used fixtures categories', 'esport' ),
				'not_found' => esc_html__( 'Not Found', 'esport' ),
			);
			$args = array(
				'labels' => $labels,
				'hierarchical' => true,
				'public' => true,
				'show_ui' => true,
				'show_admin_column' => false,
				'show_in_nav_menus' => true,
				'show_fixturescatcloud' => true,
			);
			register_taxonomy( 'fixturescat', array( 'fixtures'), $args );

		}
		add_action( 'init', 'fixturescat', 0 );
	}
	/*--------------- FIXTURE CATEGORIES END ---------------*/
/*--------------- TAXONOMY END ---------------*/

/*--------------- VC ELEMENTS START ---------------*/

	/*------------- ESPORT SLIDER START -------------*/
	function esport_slider_output( $atts, $content = null ) {		
		$output = '';
			$output .= '<div class="swiper-container esport-slider-carousel gloria-sliders" data-item="1" data-sloop="true" data-column-space="0" data-effect="fade" data-effectTime="" data-autoplay="5000" data-pagination=".swiper-pagination">';
				$output .= '<div class="swiper-wrapper">';
					$output .= do_shortcode( $content );
				$output .= '</div>';
				$output .= '<div class="swiper-pagination"></div>';
			$output .= '</div>';

			return $output;
	}
	add_shortcode( "esport_slider", "esport_slider_output" );

	function esport_slider_item_shortcode( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'sliderimage' => '',
				'toptitle' => '',
				'maintitle' => '',
				'maintext' => '',
				'link1' => '',
				'link2' => '',
			), $atts
		);
		
		$output = '';

		if( !empty( $atts["maintitle"] ) ) {
			$output .= '<div class="swiper-slide">';
				$output .= '<div class="slider-wrapper">';
					if( !empty( $atts["sliderimage"] ) ) {
						if( !empty( $atts["sliderimage"] ) ) {
							$image = $atts["sliderimage"];
							$output .= '<div class="image" style="background-image:url(' . wp_get_attachment_image_url( $image, 'esport-slider', true, array( "alt" => $atts["maintitle"] ) ) . ');"></div>';
						}
					}
					if( !empty( $atts["maintext"] ) or !empty( $atts["maintitle"] ) or !empty( $atts["toptitle"] ) or !empty( $atts["link1"] ) or !empty( $atts["link2"] ) ) {
						$output .= '<div class="content container">';
							if( !empty( $atts["toptitle"] ) ) {
								$output .= '<div class="top-title">' . esc_attr( $atts["toptitle"] ) . '</div>';
							}
							if( !empty( $atts["maintitle"] ) ) {
								$output .= '<div class="title">' . esc_attr( $atts["maintitle"] ) . '</div>';
							}
							if( !empty( $atts["maintext"] ) ) {
								$output .= '<p>' . esc_attr( $atts["maintext"] ) . '</p>';
							}
							if( !empty( $atts["link1"] ) or !empty( $atts["link2"] ) ) {
								$output .= '<div class="buttons">';
									if( !empty( $atts["link1"] ) ) {
										$href = $atts["link1"];
										$href = vc_build_link( $href );
										if( !empty( $href["target"] ) ) {
											$target = $href["target"];
										} else {
											$target = "_parent";
										}
										if( !empty( $href["title"] ) ) {
											$output .= '<a href="' . esc_url( $href["url"] ) . '" target="' . esc_attr( $target ) . '" title="' . esc_attr( $href["title"] ) . '"><span>' . esc_attr( $href["title"] ) . '</span></a>';
										}
									}
									if( !empty( $atts["link2"] ) ) {
										$href = $atts["link2"];
										$href = vc_build_link( $href );
										if( !empty( $href["link2"] ) ) {
											$target = $href["target"];
										} else {
											$target = "_parent";
										}
										if( !empty( $href["title"] ) ) {
											$output .= '<a href="' . esc_url( $href["url"] ) . '" target="' . esc_attr( $target ) . '" title="' . esc_attr( $href["title"] ) . '"><span>' . esc_attr( $href["title"] ) . '</span></a>';
										}
									}
								$output .= '</div>';
							}
						$output .= '</div>';
					}
				$output .= '</div>';
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode("esport_slider_item", "esport_slider_item_shortcode");

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__( 'eSport Slider', 'esport' ),
			"base" => "esport_slider",
			"as_parent" => array('only' => 'esport_slider_item'),
			"js_view" => 'VcColumnView',
			"content_element" => true,
			"category" => esc_html__( 'eSport Theme', 'esport' ),
			"icon" => get_template_directory_uri() . '/assets/img/icons/esport-slider.jpg',
			"description" =>esc_html__( 'eSport slider element.', 'esport' ),
		)
		);
	}

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__("eSport Slider Item", 'esport'),
			"base" => "esport_slider_item",
			"as_child" => array( 'only' => 'esport_slider' ),
			"content_element" => true,
			"category" => esc_html__("eSport Theme", 'esport'),
			"icon" => get_template_directory_uri().'/assets/img/icons/esport-slider.jpg',
			"description" =>esc_html__( 'eSport slider item element.','esport'),
			"params" => array(
				array(
					"type" => "attach_image",
					"heading" => esc_html__( 'Image', 'esport' ),
					"description" => esc_html__( 'You can upload the slider image.', 'esport' ),
					"param_name" => "sliderimage",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Top Title', 'esport' ),
					"description" => esc_html__( 'You can enter the top title.', 'esport' ),
					"param_name" => "toptitle",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Main Title', 'esport' ),
					"description" => esc_html__( 'You can enter the main title.', 'esport' ),
					"param_name" => "maintitle",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Text', 'esport' ),
					"description" => esc_html__( 'You can enter the text.', 'esport' ),
					"param_name" => "maintext",
				),
				array(
					"type" => "vc_link",
					"heading" => esc_html__( 'Link 1', 'esport' ),
					"description" => esc_html__( 'You can enter the link 1.', 'esport' ),
					"param_name" => "link1",
				),
				array(
					"type" => "vc_link",
					"heading" => esc_html__( 'Link 2', 'esport' ),
					"description" => esc_html__( 'You can enter the link 2.', 'esport' ),
					"param_name" => "link2",
				)
			)
		) );
	}

	if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
		class WPBakeryShortCode_esport_slider extends WPBakeryShortCodesContainer {}
	}
	/*------------- ESPORT SLIDER END -------------*/

	/*------------- ESPORT CONTENT TITLE START -------------*/
	function esport_content_title_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'size' => '',
				'style' => '',
				'titleone' => '',
				'titletwo' => '',
				'description' => '',
			), $atts
		);

		$output = "";

		if( !empty( $atts["titleone"] ) or !empty( $atts["titletwo"] ) or !empty( $atts["description"] ) ) {
			$output .= '<div class="content-title-element ' . esc_attr( $atts["style"] ) . ' ' . esc_attr( $atts["size"] ) . '">';
				if( !empty( $atts["titleone"] ) or !empty( $atts["titletwo"] ) ) {
					$output .= '<div class="title">';
						if( !empty( $atts["titleone"] ) ) {
							$output .= esc_attr( $atts["titleone"] );
						}
						if( !empty( $atts["titleone"] ) or !empty( $atts["titletwo"] ) ) {
							$output .= ' ';
						}
						if( !empty( $atts["titletwo"] ) ) {
							$output .= '<span>' . esc_attr( $atts["titletwo"] ) . '</span>';
						}
					$output .= '</div>';
				}
				if( !empty( $atts["description"] ) ) {
					$output .= '<div class="description">' . esc_attr( $atts["description"] ) . '</div>';
				}
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "esport_content_title", "esport_content_title_output" );

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__( 'eSport Title', 'esport' ),
			"base" => "esport_content_title",
			"category" => esc_html__( 'eSport Theme', 'esport' ),
			"icon" => get_template_directory_uri() . '/assets/img/icons/esport-content-title.jpg',
			"description" =>esc_html__( 'eSport title element.', 'esport' ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Size', 'esport' ),
					"description" => esc_html__( 'You can select the title size.', 'esport' ),
					"param_name" => "size",
					'save_always' => true,
					'value' => array(
						esc_html__( 'Size 1', 'esport' ) => 'size1',
						esc_html__( 'Size 2', 'esport' ) => 'size2',
					),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Style', 'esport' ),
					"description" => esc_html__( 'You can select the title style.', 'esport' ),
					"param_name" => "style",
					'save_always' => true,
					'value' => array(
						esc_html__( 'Dark', 'esport' ) => 'dark',
						esc_html__( 'White', 'esport' ) => 'white',
					),
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( "Title One", 'esport' ),
					"description" => esc_html__( 'You can enter the title for the one color font.', 'esport' ),
					"param_name" => "titleone",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Title Two', 'esport' ),
					"description" => esc_html__( 'You can enter the title for the two color font.', 'esport' ),
					"param_name" => "titletwo",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Description', 'esport' ),
					"description" => esc_html__( 'You can enter the description.', 'esport' ),
					"param_name" => "description",
				),
			),
		)
		);
	}
	/*------------- ESPORT CONTENT TITLE END -------------*/

	/*------------- ESPORT CONTENT TITLE START -------------*/
	function esport_achievement_box_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'style' => '',
				'point' => '',
				'title' => '',
				'description' => '',
			), $atts
		);

		$output = "";

		if( !empty( $atts["title"] ) or !empty( $atts["point"] ) or !empty( $atts["description"] ) ) {
			$output .= '<div class="achievement-box ' . esc_attr( $atts["style"] ) . '">';
				if( !empty( $atts["point"] ) ) {
					$output .= '<div class="point">';
						$output .= '<i class="fa fa-star" aria-hidden="true"></i>';
						$output .= '<span>' . esc_attr( $atts["point"] ) . '</span>';
					$output .= '</div>';
				}
				if( !empty( $atts["title"] ) or !empty( $atts["description"] ) ) {
					$output .= '<div class="content">';
						if( !empty( $atts["title"] ) ) {
							$output .= '<div class="title">';
								$output .= esc_attr( $atts["title"] );
							$output .= '</div>';
						}
						if( !empty( $atts["description"] ) ) {
							$output .= '<div class="description">' . esc_attr( $atts["description"] ) . '</div>';
						}
					$output .= '</div>';
				}
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "esport_achievement_box", "esport_achievement_box_output" );

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__( 'eSport Achievement Box', 'esport' ),
			"base" => "esport_achievement_box",
			"category" => esc_html__( 'eSport Theme', 'esport' ),
			"icon" => get_template_directory_uri() . '/assets/img/icons/esport-achievement-box.jpg',
			"description" =>esc_html__( 'eSport achievement box element.', 'esport' ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Style', 'esport' ),
					"description" => esc_html__( 'You can select the style.', 'esport' ),
					"param_name" => "style",
					'save_always' => true,
					'value' => array(
						esc_html__( 'Dark', 'esport' ) => 'dark',
						esc_html__( 'White', 'esport' ) => 'white',
					),
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( "Point", 'esport' ),
					"description" => esc_html__( 'You can enter the point', 'esport' ),
					"param_name" => "point",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Title', 'esport' ),
					"description" => esc_html__( 'You can enter the title.', 'esport' ),
					"param_name" => "title",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Description', 'esport' ),
					"description" => esc_html__( 'You can enter the description.', 'esport' ),
					"param_name" => "description",
				),
			),
		)
		);
	}
	/*------------- ESPORT CONTENT TITLE END -------------*/

	/*------------- ESPORT BUTTON START -------------*/
	function esport_button_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'style' => '',
				'align' => '',
				'buttonlink' => '',
			), $atts
		);
		
		$output = '';

		if( !empty( $atts["buttonlink"] ) ) {
			$output .= '<div class="esport-button ' . esc_attr( $atts["style"] ) . ' ' . esc_attr( $atts["align"] ) . '">';
				$href = $atts["buttonlink"];
				$href = vc_build_link( $href );
				if( !empty( $href["target"] ) ) {
					$target = $href["target"];
				} else {
					$target = "_parent";
				}
				$output .= '<a href="' . esc_url( $href["url"] ) . '" target="' . esc_attr( $target ) . '" title="' . esc_attr( $href["title"] ) . '">';
					$output .= '<span>' . esc_attr( $href["title"] ) . '</span>';
				$output .= '</a>';
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "esport_button", "esport_button_output" );

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__( 'eSport Button', 'esport' ),
			"base" => "esport_button",
			"category" => esc_html__( 'eSport Theme', 'esport' ),
			"icon" => get_template_directory_uri() . '/assets/img/icons/esport-button.jpg',
			"description" =>esc_html__( 'eSport button element.', 'esport' ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Style', 'esport' ),
					"description" => esc_html__( 'You can select the style.', 'esport' ),
					"param_name" => "style",
					'save_always' => true,
					'value' => array(
						esc_html__( 'Dark', 'esport' ) => 'dark',
						esc_html__( 'White', 'esport' ) => 'white',
					),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Align', 'esport' ),
					"description" => esc_html__( 'You can select the align of button.', 'esport' ),
					"param_name" => "align",
					'save_always' => true,
					'value' => array(
						esc_html__( 'Left', 'esport' ) => 'left',
						esc_html__( 'Right', 'esport' ) => 'right',
						esc_html__( 'Center', 'esport' ) => 'center',
					),
				),
				array(
					"type" => "vc_link",
					"heading" => esc_html__( 'Button Link', 'esport' ),
					"description" => esc_html__( 'You can enter the button link.', 'esport' ),
					"param_name" => "buttonlink",
				)
			),
		)
		);
	}
	/*------------- ESPORT BUTTON END -------------*/

	/*------------- PLAYER LIST START -------------*/
	function esport_player_list_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'gametab' => '',
				'excludeposts' => '',
				'includemembers' => '',
				'playercount' => '',
			), $atts
		);
		
		$output = '';

		if( !empty( $atts['excludeposts'] ) ) {
			$excludeposts = $atts['excludeposts'];
			$exclude = explode( ',', $excludeposts );
		} else {
			$exclude = "";
		}

		if( !empty( $atts['includemembers'] ) ) {
			$includemembers = $atts['includemembers'];
			$include = explode( ',', $includemembers );
		} else {
			$include = "";
		}

		if( !empty( $atts['playercount'] ) ) {
			$playercount = $atts['playercount'];
		} else {
			$playercount = "";
		}

		$output .= '<div class="player-team-list-wrapper">';
			if( $atts["gametab"] == "true" ) {
				$game_terms = get_terms( array( 'taxonomy' => 'game' ) );
				if ( ! empty( $game_terms ) && ! is_wp_error( $game_terms ) ){
					$output .= '<ul class="nav nav-tabs" role="tablist">';
						foreach ( $game_terms as $game_term ) {
							$name = $game_term->name;
							$logo = get_term_meta( $game_term->term_id, 'esport_game_logo', true );
							
							$output .= '<li role="presentation"><a href="#game_id_' . esc_attr( $game_term->term_id ) . '" aria-controls="game_id_' . esc_attr( $game_term->term_id ) . '" role="tab" data-toggle="tab">';
								
								if( !empty( $logo ) ) {
									$output .= '<img src="' . esc_url( $logo ) . '" alt="' . esc_attr( $name ) . '" />';
								} else {
									$output .= '<span>' . esc_attr( $name ) . '</span>';
								}
								
							$output .= '</a></li>';
						}
					$output .= '</ul>';
				}

				if ( ! empty( $game_terms ) && ! is_wp_error( $game_terms ) ){
					$output .= '<div class="tab-content">';

						if( !empty( $atts['includemembers'] ) and $atts["gametab"] == "false" ) {
							$player_args = array (
								'posts_per_page' => $playercount,
								'post_type' => 'player',
								'post_status' => 'publish',
								'post__in' => $include,
								'post__not_in' => $exclude,
								'ignore_sticky_posts' => true,
							);
							
							$player_query = new WP_Query( $player_args );
							
							if ( $player_query->have_posts() ) {
								$output .= '<ul class="team-player-list">';
									while ( $player_query->have_posts() ) {
										$player_query->the_post();
	                                    $output .= '<li>';
	                                    	$output .= esport_player_template( get_the_ID() );
	                                    $output .= '</li>';
									}
								$output .= '</ul>';
							}
							wp_reset_postdata();
						}

						foreach ( $game_terms as $game_term ) {
							$output .= '<div role="tabpanel" class="tab-pane" id="game_id_' . esc_attr( $game_term->term_id ) . '">';
							
								$player_args = array (
									'posts_per_page' => $playercount,
									'post_type' => 'player',
									'post_status' => 'publish',
									'post__in' => $include,
									'post__not_in' => $exclude,
									'ignore_sticky_posts' => true,
									'tax_query' => array(
										array(
											'taxonomy' => 'game',
											'field'    => 'id',
											'terms'    => array( $game_term->term_id ),
										),
									),
								);
								
								$player_query = new WP_Query( $player_args );
								
								if ( $player_query->have_posts() ) {
									$output .= '<ul class="team-player-list">';
										while ( $player_query->have_posts() ) {
											$player_query->the_post();
		                                    $output .= '<li>';
		                                    	$output .= esport_player_template( get_the_ID() );
		                                    $output .= '</li>';
										}
									$output .= '</ul>';
								}
								wp_reset_postdata();
								
							$output .= '</div>';
						}
						
					$output .= '</div>';
					
				}
			} else {
							
				$player_args = array (
					'posts_per_page' => $playercount,
					'post_type' => 'player',
					'post__not_in' => $exclude,
					'post__in' => $include,
					'post_status' => 'publish',
					'ignore_sticky_posts' => true,
				);
				
				$player_query = new WP_Query( $player_args );
				
				if ( $player_query->have_posts() ) {
					$output .= '<ul class="team-player-list">';
						while ( $player_query->have_posts() ) {
							$player_query->the_post();
                            $output .= '<li>';
                            	$output .= esport_player_template( get_the_ID() );
                            $output .= '</li>';
						}
					$output .= '</ul>';
				}
				wp_reset_postdata();

			}
		$output .= '</div>';

		return $output;
	}
	add_shortcode( "esport_player_list", "esport_player_list_output" );

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__( 'eSport Player List', 'esport' ),
			"base" => "esport_player_list",
			"category" => esc_html__( 'eSport Theme', 'esport' ),
			"icon" => get_template_directory_uri() . '/assets/img/icons/player-list.jpg',
			"description" =>esc_html__( 'eSport player list element.', 'esport' ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Game Tab', 'esport' ),
					"description" => esc_html__( 'You can select the style.', 'esport' ),
					"param_name" => "gametab",
					'save_always' => true,
					'value' => array(
						esc_html__( 'True', 'esport' ) => 'true',
						esc_html__( 'False', 'esport' ) => 'false',
					),
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Exclude Players', 'esport' ),
					"description" => esc_html__( 'You can enter the player ids. Separate with commas 1,2,3 etc.', 'esport' ),
					"param_name" => "excludeposts",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Include Players', 'esport' ),
					"description" => esc_html__( 'You can enter the player ids. Separate with commas 1,2,3 etc.', 'esport' ),
					"param_name" => "includemembers",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Player Count', 'esport' ),
					"description" => esc_html__( 'You can enter the player count.', 'esport' ),
					"param_name" => "playercount",
				)
			),
		)
		);
	}
	/*------------- PLAYER LIST END -------------*/

	/*------------- TEAM LIST START -------------*/
	function esport_team_list_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'excludeposts' => '',
				'membercount' => '',
			), $atts
		);
		
		$output = '';

		if( !empty( $atts['excludeposts'] ) ) {
			$excludeposts = $atts['excludeposts'];
			$exclude = explode( ',', $excludeposts );
		} else {
			$exclude = "";
		}

		$output .= '<div class="player-team-list-wrapper">';
			$player_args = array (
				'posts_per_page' => $atts["membercount"],
				'post_type' => 'team',
				'post__not_in' => $exclude,
				'post_status' => 'publish',
				'ignore_sticky_posts' => true,
			);
			
			$player_query = new WP_Query( $player_args );
			
			if ( $player_query->have_posts() ) {
				$output .= '<ul class="team-player-list">';
					while ( $player_query->have_posts() ) {
						$player_query->the_post();
                        $output .= '<li>';
                        	$output .= esport_player_template( get_the_ID() );
                        $output .= '</li>';
					}
				$output .= '</ul>';
			}
			wp_reset_postdata();
		$output .= '</div>';

		return $output;
	}
	add_shortcode( "esport_team_list", "esport_team_list_output" );

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__( 'eSport Team List', 'esport' ),
			"base" => "esport_team_list",
			"category" => esc_html__( 'eSport Theme', 'esport' ),
			"icon" => get_template_directory_uri() . '/assets/img/icons/team-list.jpg',
			"description" =>esc_html__( 'eSport team list element.', 'esport' ),
			"params" => array(
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Exclude Members', 'esport' ),
					"description" => esc_html__( 'You can enter the member ids. Separate with commas 1,2,3 etc.', 'esport' ),
					"param_name" => "excludeposts",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Member Count', 'esport' ),
					"description" => esc_html__( 'You can enter the member count.', 'esport' ),
					"param_name" => "membercount",
				)
			),
		)
		);
	}
	/*------------- PLAYER LIST END -------------*/

	/*------------- FIXTURES START -------------*/
	function esport_fixtures_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'visible' => '',
				'matchcount' => '',
				'excludeposts' => '',
				'contentareanot' => '',
			), $atts
		);

		$output = '';

		if( !empty( $atts['excludeposts'] ) ) {
			$excludeposts = $atts['excludeposts'];
			$exclude = explode( ',', $excludeposts );
		} else {
			$exclude = "";
		}

		if( !empty( $atts['matchcount'] ) ) {
			$matchcount = $atts['matchcount'];
		} else {
			$matchcount = "";
		}

		if( !empty( $atts["contentareanot"] ) ) {
			$contentareanot = "contentareanot";
		} else {
			$contentareanot = "";
		}

		$output .= '<div class="fixtures-wrapper ' . esc_attr( $contentareanot ) . '">';
			$fixturescat_terms = get_terms( array( 'taxonomy' => 'fixturescat' ) );
			if ( ! empty( $fixturescat_terms ) && ! is_wp_error( $fixturescat_terms ) ){
				$output .= '<ul class="nav nav-tabs" role="tablist">';
					foreach ( $fixturescat_terms as $fixturescat_term ) {
						$name = $fixturescat_term->name;
						$output .= '<li role="presentation"><a href="#game_id_' . esc_attr( $fixturescat_term->term_id ) . '" aria-controls="game_id_' . esc_attr( $fixturescat_term->term_id ) . '" role="tab" data-toggle="tab">';
							$output .= '<span>' . esc_attr( $name ) . '</span>';						
						$output .= '</a></li>';
					}
				$output .= '</ul>';
			}

			if ( ! empty( $fixturescat_terms ) && ! is_wp_error( $fixturescat_terms ) ){
				$output .= '<div class="tab-content">';
				
					foreach ( $fixturescat_terms as $fixturescat_term ) {
						$output .= '<div role="tabpanel" class="tab-pane" id="game_id_' . esc_attr( $fixturescat_term->term_id ) . '">';
						
							$fixtures_args = array (
								'posts_per_page' => $matchcount,
								'post_type' => 'fixtures',
								'post_status' => 'publish',
								'post__not_in' => $exclude,
								'ignore_sticky_posts' => true,
								'tax_query' => array(
									array(
										'taxonomy' => 'fixturescat',
										'field'    => 'id',
										'terms'    => array( $fixturescat_term->term_id ),
									),
								),
							);
							$fixtures_query = new WP_Query( $fixtures_args );
							
							if ( $fixtures_query->have_posts() ) {
								$output .= '<ul class="fixture-list">';
									while ( $fixtures_query->have_posts() ) {
										$fixtures_query->the_post();
										$match_home_team = get_post_meta( get_the_ID(), 'match_home_team', true );
										$match_home_team_score = get_post_meta( get_the_ID(), 'match_home_team_score', true );
										$match_away_team = get_post_meta( get_the_ID(), 'match_away_team', true );
										$match_away_team_score = get_post_meta( get_the_ID(), 'match_away_team_score', true );
										$match_date = get_post_meta( get_the_ID(), 'match_date', true );
										$match_time = get_post_meta( get_the_ID(), 'match_time', true );
	                                    $output .= '<li>';
	                                    	$output .= '<div class="left">';
	                                    		$terms = wp_get_post_terms( get_the_ID(), 'game' );
												if ( $terms && ! is_wp_error( $terms ) ) {
													$output .= '<div class="game">';
													foreach ( $terms as $term ) {
	                                    				$output .= '<span>' . $term->name . '</span>';
													}
													$output .= '</div>';
												}
	                                    		$output .= '<div class="title">' . get_the_title() . '</div>';
	                                    		$output .= '<div class="text">' . get_the_content() . '</div>';
	                                    	$output .= '</div>';
                                    		if( !empty( $match_home_team ) or !empty( $match_home_team_score ) or !empty( $match_away_team ) or !empty( $match_away_team_score ) or !empty( $match_date ) or !empty( $match_time ) ) {
		                                    	$output .= '<div class="right">';
		                                    		if( !empty( $match_home_team ) ) {
		                                    			$output .= '<div class="home-team team-details">';
															$home_team = get_term( $match_home_team, 'club' );
															$home_team_name = $home_team->name;
															$home_team_logo = get_term_meta( $match_home_team, 'esport_club_logo', true );
															$team_logo_attachment_id = esport_get_attachment_id_from_guid( $home_team_logo );
															$home_team_logo = wp_get_attachment_image_url( $team_logo_attachment_id, 'esport-team-logo', true, true );
															if( !empty( $home_team_logo ) ) {
																$output .= '<img src="' . esc_url( $home_team_logo ) . '" alt="' . esc_attr( $home_team_name ) . '" />';
															}
															if( $atts["visible"] == "visible" ) {
																$output .= '<span class="team-name">' . esc_attr( $home_team_name ) . '</span>';
															}
															$output .= '';
		                                    			$output .= '</div>';
		                                    		}
		                                    		if( !empty( $match_home_team_score ) or !empty( $match_away_team_score ) or !empty( $match_date ) or !empty( $match_time ) ) {
		                                    			$output .= '<div class="score-date">';

			                                    			$output .= '<div class="score">';
			                                    				if( !empty( $match_home_team_score ) or $match_home_team_score == "0" ) {
			                                    					$output .= '<span class="home-team-score">' . esc_attr( $match_home_team_score ) . '</span>';
			                                    				}
			                                    				if( !empty( $match_home_team_score ) or !empty( $match_away_team_score ) or $match_home_team_score == "0" or $match_away_team_score == "0" ) {
			                                    					$output .= '<span class="separate">-</span>';
			                                    				} else {
			                                    					$output .= '<span class="vs">' . esc_html__( 'vs', 'esport' ) . '</span>';
			                                    				}
			                                    				if( !empty( $match_away_team_score ) or $match_away_team_score == "0" ) {
			                                    					$output .= '<span class="away-team-score">' . esc_attr( $match_away_team_score ) . '</span>';
			                                    				}
			                                    			$output .= '</div>';

			                                    			if( !empty( $match_date ) or !empty( $match_time ) ) {
				                                    			$output .= '<div class="date-time">';
					                                    			$output .= '<div class="date-time-wrapper">';
					                                    				if( !empty( $match_date ) ) {
				                                    						$output .= esport_global_date_format( $date = esc_attr( $match_date ) );
					                                    				}
					                                    				if( !empty( $match_date ) or !empty( $match_time ) ) {
					                                    					$output .= ' - ';
					                                    				}
					                                    				if( !empty( $match_time ) ) {
				                                    						$output .= esc_attr( $match_time );
					                                    				}
					                                    			$output .= '</div>';
				                                    			$output .= '</div>';
			                                    			}
			                                    			
		                                    			$output .= '</div>';
		                                    		}
		                                    		if( !empty( $match_away_team ) ) {
		                                    			$output .= '<div class="away-team team-details">';
															$away_team = get_term( $match_away_team, 'club' );
															$away_team_name = $away_team->name;
															$away_team_logo = get_term_meta( $match_away_team, 'esport_club_logo', true );
															$team_logo_attachment_id = esport_get_attachment_id_from_guid( $away_team_logo );
															$away_team_logo = wp_get_attachment_image_url( $team_logo_attachment_id, 'esport-team-logo', true, true );
															if( !empty( $away_team_logo ) ) {
																$output .= '<img src="' . esc_url( $away_team_logo ) . '" alt="' . esc_attr( $away_team_name ) . '" />';
															}
															if( $atts["visible"] == "visible" ) {
																$output .= '<span class="team-name">' . esc_attr( $away_team_name ) . '</span>';
															}
															$output .= '';
		                                    			$output .= '</div>';
		                                    		}
		                                    	$output .= '</div>';
                                    		}
	                                    $output .= '</li>';
									}
								$output .= '</ul>';
							} else {
							}
							wp_reset_postdata();
							
						$output .= '</div>';
					}
					
				$output .= '</div>';
				
			}
		$output .= '</div>';

		return $output;
	}
	add_shortcode( "esport_fixtures", "esport_fixtures_output" );

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__( 'eSport Fixtures', 'esport' ),
			"base" => "esport_fixtures",
			"category" => esc_html__( 'eSport Theme', 'esport' ),
			"icon" => get_template_directory_uri() . '/assets/img/icons/fixtures.jpg',
			"description" =>esc_html__( 'eSport fixtures element.', 'esport' ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Theme Name', 'esport' ),
					"description" => esc_html__( 'You can select the theme name status.', 'esport' ),
					"param_name" => "visible",
					'save_always' => true,
					'value' => array(
						esc_html__( 'Visible', 'esport' ) => 'visible',
						esc_html__( 'Hide', 'esport' ) => 'hide',
					),
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Exclude Match', 'esport' ),
					"description" => esc_html__( 'You can enter the match ids. Separate with commas 1,2,3 etc.', 'esport' ),
					"param_name" => "excludeposts",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Match Count', 'esport' ),
					"description" => esc_html__( 'You can enter the match count.', 'esport' ),
					"param_name" => "matchcount",
				),
				array(
					"type" => "checkbox",
					"heading" => esc_html__( "Don't Use the Content Area", 'esport' ),
					"description" => esc_html__( "If you don't use the content area, choose checkbox.", 'esport' ),
					"param_name" => "contentareanot",
				)
			),
		)
		);
	}
	/*------------- FIXTURE END -------------*/

	/*------------- LOGO CAROUSEL START -------------*/
	function esport_logo_carousel_shortcode( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'style' => '',
				'autoplay' => '',
				'loop' => '',
				'column' => '',
				'navigation' => '',
				'columnspace' => '',
			), $atts
		);
		
		$output = '';

			if( !empty( $atts["column"] ) ) {
				$column = $atts["column"];
			} else {
				$column = "5";
			}

			if( !empty( $atts["columnspace"] ) ) {
				$columnspace = $atts["columnspace"];
			} else {
				$columnspace = "15";
			}
			
			$output .= '<div class="swiper-container logo-carousel gloria-sliders ' . esc_attr( $atts["style"] ) . '" data-column-space="' . esc_attr( $columnspace ) . '" data-aplay="' . esc_attr( $atts["autoplay"] ) . '" data-item="' . esc_attr( $column ) . '" data-sloop="' . esc_attr( $atts["loop"] ) . '">';
				$output .= '<div class="swiper-wrapper">';
						$output .= do_shortcode( $content );
				$output .= '</div>';
				if( $atts["navigation"] == "true" ) {
					$output .= '<div class="pagination-buttons">
									<div class="slider-prev prev"><i class="fa fa-angle-left" aria-hidden="true"></i></div>
									<div class="slider-next next"><i class="fa fa-angle-right" aria-hidden="true"></i></div>
								</div>';					
				}
			$output .= '</div>';
				

		return $output;
	}
	add_shortcode("esport_logo_carousel", "esport_logo_carousel_shortcode");

	function esport_logo_shortcode( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'logoimage' => '',
				'logolink' => ''
			), $atts
		);
		
		$output = '';
		
		if( !empty( $atts['logoimage'] ) ) {
			$image = wp_get_attachment_image_src( $atts["logoimage"], "full" );
			$output .= '<div class="swiper-slide">';
				if( !empty( $atts["logolink"] ) ) {
					$output .= '<div class="logo-item">';
						$href = $atts["logolink"];
						$href = vc_build_link( $href );
						if( !empty( $href["target"] ) ) {
							$target = $href["target"];
						} else {
							$target = "_parent";
						}
						$output .= '<a href="' . esc_url( $href["url"] ) . '" target="' . esc_attr( $target ) . '" title="' . esc_attr( $href["title"] ) . '" ><img src="' . esc_url( $image[0] ) . '" alt="' . esc_attr( $href["title"] ) . '" /></a>';
					$output .= '</div>';
				}
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode("esport_logo", "esport_logo_shortcode");

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__( "eSport Logo Carousel", 'esport' ),
			"base" => "esport_logo_carousel",
			"class" => "",
			"as_parent" => array('only' => 'esport_logo'),
			"js_view" => 'VcColumnView',
			"content_element" => true,
			"category" => esc_html__( "eSport Theme", 'esport' ),
			"icon" => get_template_directory_uri().'/assets/img/icons/esport_logo.png',
			"description" =>esc_html__( 'eSport logo carousel widget.','esport' ),
			"params" => array(
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => esc_html__("Style",'esport'),
					"description" => esc_html__("You can select the style.",'esport'),
					"param_name" => "style",
					"value" => array(
						esc_html__("Style 1", 'esport') => "style1",
						esc_html__("Style 2", 'esport') => "style2",
					)
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Autoplay', 'esport' ),
					"description" => esc_html__( 'You can enter the autoplay delay. Example: 5000. Leave blank to autoplay disabled.', 'esport' ),
					"param_name" => "autoplay",
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => esc_html__("Loop",'esport'),
					"description" => esc_html__("You can select the loop status.",'esport'),
					"param_name" => "loop",
					"value" => array(
						esc_html__("False", 'esport') => "false",
						esc_html__("True", 'esport') => "true",
					)
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Column', 'esport' ),
					"description" => esc_html__( 'You can enter the column.', 'esport' ),
					"param_name" => "column",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Column Space', 'esport' ),
					"description" => esc_html__( 'You can enter the column space.', 'esport' ),
					"param_name" => "columnspace",
				),
				array(
					"type" => "dropdown",
					"class" => "",
					"heading" => esc_html__("Navigation",'esport'),
					"description" => esc_html__("You can select the navigation status.",'esport'),
					"param_name" => "navigation",
					"value" => array(
						esc_html__("False", 'esport') => "false",
						esc_html__("True", 'esport') => "true",
					)
				),
			)
		) );
	}

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__( "eSport Logo Carousel Item", 'esport' ),
			"base" => "esport_logo",
			"class" => "",
			"as_child" => array( 'only' => 'esport_logo_carousel' ),
			"content_element" => true,
			"category" => esc_html__( "eSport Theme", 'esport' ),
			"icon" => get_template_directory_uri().'/assets/img/icons/esport_logo.png',
			"description" =>esc_html__( 'eSport logo carousel element item.','esport' ),
			"params" => array(
				array(
					"type" => "attach_image",
					"class" => "",
					"heading" => esc_html__( "Image",'esport' ),
					"description" => esc_html__( "You can the upload your logo.", 'esport' ),
					"param_name" => "logoimage",
					"value" => "",
				),
				array(
					"type" => "vc_link",
					"class" => "",
					"heading" => esc_html__( "Logo Link",'esport' ),
					"description" => esc_html__( "You can enter the logo link.", 'esport' ),
					"param_name" => "logolink",
					"value" => "",
				),
			)
		) );
	}

	if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
		class WPBakeryShortCode_esport_logo_carousel extends WPBakeryShortCodesContainer {}
	}
	/*------------- LOGO CAROUSEL END -------------*/

	/*------------- ESPORT LATEST POSTS START -------------*/
	function esport_latest_posts_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'excludeposts' => '',
				'posttag' => '',
				'postids' => '',
				'offset' => '',
				'postcount' => '',
				'style' => '',
				'pagination' => '',
				'categoryname' => '',
				'postinformation' => '',
				'excerpt' => '',
				'readmore' => '',
			), $atts
		);
		
		$output = '';

		if( !empty( $atts['excludeposts'] ) ) {
			$excludeposts = $atts['excludeposts'];
			$exclude = explode( ',', $excludeposts );
		} else {
			$exclude = "";
		}

		if( !empty( $atts['postids'] ) ) {
			$postids = explode( ',', $atts['postids'] );
		} else {
			$postids = "";
		}

		if( $atts['categoryname'] == "true" ) {
			$category_status = "true";
		} else {
			$category_status = "";
		}

		if( $atts['postinformation'] == "true" ) {
			$information_status = "true";
		} else {
			$information_status = "";
		}

		if( $atts['excerpt'] == "true" ) {
			$excerpt_status = "true";
		} else {
			$excerpt_status = "";
		}

		if( $atts['readmore'] == "true" ) {
			$readmore_status = "true";
		} else {
			$readmore_status = "";
		}

		$style = $atts['style'];

		$paged = is_front_page() ? get_query_var( 'page', 1 ) : get_query_var( 'paged', 1 );
		if( empty( $paged ) ) { $paged = 1; }

		$query_arg = array(
			'posts_per_page' => $atts['postcount'],
			'post__not_in' => $exclude,
			'tag' => $atts['posttag'],
			'cat' => $atts['category'],
			'post__in' => $postids,
			'offset' => $atts['offset'],
			'paged' => $paged,
			'post_status' => 'publish',
			'ignore_sticky_posts' => true,
			'post_type' => 'post',
		);
		$post_query = new WP_Query( $query_arg );

		if ( $post_query->have_posts() ) {
			$output .= '<div class="esport-latest-posts-element ' . esc_attr( $style ) . '">';
				if( $style == "style2" ) {
					$output .= '<div class="archive-post-list-style-2 post-list">';
						while ( $post_query->have_posts() ) {
							$post_query->the_post();
							$output .= esport_post_list_style_2( $post_id = get_the_ID(), $image = "true", $category = $category_status, $excerpt = $excerpt_status, $read_more = $readmore_status, $post_info = $information_status );
						}
						wp_reset_postdata();
					$output .= '</div>';
				} elseif( $style == "style3" ) {
					$output .= '<div class="archive-post-list-style-3 post-list">';
						while ( $post_query->have_posts() ) {
							$post_query->the_post();
							$output .= esport_post_list_style_3( $post_id = get_the_ID(), $image = "true", $post_info = $information_status );
						}
						wp_reset_postdata();
					$output .= '</div>';
				} elseif( $style == "style4" ) {
					$output .= '<div class="archive-post-list-style-4 post-list">';
						while ( $post_query->have_posts() ) {
							$post_query->the_post();
							$output .= esport_post_list_style_2( $post_id = get_the_ID(), $image = "true", $category = $category_status, $excerpt = $excerpt_status, $read_more = $readmore_status, $post_info = $information_status );
						}
						wp_reset_postdata();
					$output .= '</div>';
				} elseif( $style == "style5" ) {
					$output .= '<div class="archive-post-list-style-5 post-list">';
						while ( $post_query->have_posts() ) {
							$post_query->the_post();
							$output .= esport_post_list_style_2( $post_id = get_the_ID(), $image = "true", $category = $category_status, $excerpt = $excerpt_status, $read_more = $readmore_status, $post_info = $information_status );
						}
						wp_reset_postdata();
					$output .= '</div>';
				} else {
					$output .= '<div class="archive-post-list-style-1 post-list">';
						while ( $post_query->have_posts() ) {
							$post_query->the_post();
							$output .= esport_post_list_style_1( $post_id = get_the_ID(), $image = "true", $category = $category_status, $excerpt = $excerpt_status, $read_more = $readmore_status, $post_info = $information_status );
						}
						wp_reset_postdata();
					$output .= '</div>';
				}

				if ( $atts['pagination'] == 'true' ) {
					$output .= esport_latest_posts_pagination( $paged = $paged, $query = $post_query );
				}
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "esport_latest_posts", "esport_latest_posts_output" );

	if(function_exists('vc_map')){
		$posts_list = get_posts(array(
			'orderby' => 'title',
			'order' => 'ASC',
			'post_type' => 'post'
		));

		$posts_array = array();
		$posts_array[esc_html__( 'All Categories', 'esport' )] = "-";
		foreach($posts_list as $post) {
			$posts_array[$post->post_title . " (id:" . esc_attr( $post->ID ) . ")"] = $post->ID;
		}

		$post_categories = get_terms("category");
		$post_categories_array = array();
		$post_categories_array[__("All Categories", 'esport')] = "-";
		foreach($post_categories as $post_category) {
			$post_categories_array[$post_category->name] =  $post_category->term_id;
		}

		vc_map( array(
			"name" => esc_html__( 'eSport Blog', 'esport' ),
			"base" => "esport_latest_posts",
			"category" => esc_html__( 'eSport Theme', 'esport' ),
			"icon" => get_template_directory_uri() . '/assets/img/icons/esport-latest-posts.jpg',
			"description" =>esc_html__( 'eSport blog element.', 'esport' ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Category', 'esport' ),
					"description" => esc_html__( 'You can select the category.', 'esport' ),
					"param_name" => "category",
					"value" => $post_categories_array,
					"group" => "General",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Tag', 'esport' ),
					"description" => esc_html__( 'You can enter the post tag.', 'esport' ),
					"param_name" => "posttag",
					"group" => "General",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( "Post ID's", 'esport' ),
					"description" => esc_html__( 'You can enter the post ids. Separate with commas 1,2,3 etc.', 'esport' ),
					"param_name" => "postids",
					"group" => "General",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Exclude Posts', 'esport' ),
					"description" => esc_html__( 'You can enter the post ids. Separate with commas 1,2,3 etc.', 'esport' ),
					"param_name" => "excludeposts",
					"group" => "General",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Offset', 'esport' ),
					"description" => esc_html__( 'You can enter the offset number.', 'esport' ),
					"param_name" => "offset",
					"group" => "General",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'Post Count', 'esport' ),
					"description" => esc_html__( 'You can enter the post count.', 'esport' ),
					"param_name" => "postcount",
					"group" => "General",
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Style', 'esport' ),
					"description" => esc_html__( 'You can select the element style.', 'esport' ),
					"param_name" => "style",
					"group" => "Design",
					'save_always' => true,
					'value' => array(
						esc_html__( 'Style 1', 'esport' ) => 'style1',
						esc_html__( 'Style 2', 'esport' ) => 'style2',
						esc_html__( 'Style 3', 'esport' ) => 'style3',
						esc_html__( 'Style 4', 'esport' ) => 'style4',
						esc_html__( 'Style 5', 'esport' ) => 'style5',
					),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Pagination', 'esport' ),
					"description" => esc_html__( 'You can select the pagination status.', 'esport' ),
					"param_name" => "pagination",
					"group" => "Design",
					'save_always' => true,
					'value' => array(
						esc_html__( 'False', 'esport' ) => 'false',
						esc_html__( 'True', 'esport' ) => 'true',
					),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Category Name', 'esport' ),
					"description" => esc_html__( 'You can hide the category name.', 'esport' ),
					"param_name" => "categoryname",
					"group" => "Design",
					'save_always' => true,
					'value' => array(
						esc_html__( 'False', 'esport' ) => 'false',
						esc_html__( 'True', 'esport' ) => 'true',
					),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Post Information', 'esport' ),
					"description" => esc_html__( 'You can hide the post information.', 'esport' ),
					"param_name" => "postinformation",
					"group" => "Design",
					'save_always' => true,
					'value' => array(
						esc_html__( 'False', 'esport' ) => 'false',
						esc_html__( 'True', 'esport' ) => 'true',
					),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Excerpt', 'esport' ),
					"description" => esc_html__( 'You can hide the post excerpt.', 'esport' ),
					"param_name" => "excerpt",
					"group" => "Design",
					'save_always' => true,
					'value' => array(
						esc_html__( 'False', 'esport' ) => 'false',
						esc_html__( 'True', 'esport' ) => 'true',
					),
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Read More', 'esport' ),
					"description" => esc_html__( 'You can hide the read more button.', 'esport' ),
					"param_name" => "readmore",
					"group" => "Design",
					'save_always' => true,
					'value' => array(
						esc_html__( 'False', 'esport' ) => 'false',
						esc_html__( 'True', 'esport' ) => 'true',
					),
				)
			),
		)
		);
	}
	/*------------- ESPORT LATEST POSTS END -------------*/

	/*------------- ESPORT COUNTER START -------------*/
	function esport_counter_shortcode( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'countertitle' => '',
				'style' => '',
				'counternumber' => '',
			), $atts
		);
		
		$output = '';
			
		if( !empty( $atts['counternumber'] ) or !empty( $atts['countertitle'] ) ) {
			$output .= '<div class="esport-counter ' . esc_attr( $atts["style"] ) . '">';
				if( !empty( $atts['counternumber'] ) ) {
					if( !empty( $atts['counternumber'] ) ) {
						$counternumber = esc_attr( $atts['counternumber'] );
					} else {
						$counternumber = "1";
					}

					if( !empty( $atts['counternumber'] ) ) {
						$output .= '<div class="number">' . esc_attr( $atts['counternumber'] ) . '</div>';
					}
					if( !empty( $atts['countertitle'] ) ) {
						$output .= '<div class="title">' . esc_attr( $atts['countertitle'] ) . '</div>';
					}
				}
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode("esport_counter", "esport_counter_shortcode");

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__("eSport Counter", 'esport'),
			"base" => "esport_counter",
			"class" => "",
			"category" => esc_html__("eSport Theme", 'esport'),
			"icon" => get_template_directory_uri().'/assets/img/icons/esport-counter.png',
			"description" =>esc_html__( 'eSport counter element.','esport'),
			"params" => array(
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => esc_html__("Title",'esport'),
					"description" => esc_html__("You can enter the counter title.", 'esport'),
					"param_name" => "countertitle",
					"value" => ""
				),
				array(
					"type" => "textfield",
					"class" => "",
					"heading" => esc_html__("Number",'esport'),
					"description" => esc_html__("You can enter the counter number.", 'esport'),
					"param_name" => "counternumber",
					"value" => ""
				),
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Style', 'esport' ),
					"description" => esc_html__( 'You can select the style.', 'esport' ),
					"param_name" => "style",
					'save_always' => true,
					'value' => array(
						esc_html__( 'Colored', 'esport' ) => 'colored',
						esc_html__( 'White', 'esport' ) => 'white',
					),
				),
			)
		) );
	}
	/*------------- ESPORT COUNTER END -------------*/

	/*------------- ESPORT CONTACT BOX START -------------*/
	function esport_contact_box_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'address' => '',
				'email' => '',
				'phone' => '',
				'fax' => '',
				'abouttext' => '',
			), $atts
		);
		
		$output = '';

		if( !empty( $atts["address"] ) or !empty( $atts["email"] ) or !empty( $atts["phone"] ) or !empty( $atts["fax"] ) or !empty( $atts["abouttext"] ) or !empty( $atts["aboutlink"] ) ) {
			$output .= '<div class="esport-contact-box">';
				if( !empty( $atts["abouttext"] ) ) {
					$output .= '<div class="contact-row about-text">' . esc_attr( $atts["abouttext"] ) . '</div>';
				}

				if( !empty( $atts["address"] ) ) {
					$output .= '<div class="contact-row address"><i class="fa fa-map-marker" aria-hidden="true"></i>' . esc_attr( $atts["address"] ) . '</div>';
				}

				if( !empty( $atts["email"] ) ) {
					$output .= '<div class="contact-row email"><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:' . esc_attr( str_replace(' ', '', $atts["email"] ) ) . '">' . esc_attr( $atts["email"] ) . '</a></div>';
				}

				if( !empty( $atts["phone"] ) ) {
					$output .= '<div class="contact-row phone"><i class="fa fa-phone" aria-hidden="true"></i><a href="tel:+' . esc_attr( str_replace(' ', '', $atts["phone"] ) ) . '">' . esc_attr( $atts["phone"] ) . '</a></div>';
				}

				if( !empty( $atts["fax"] ) ) {
					$output .= '<div class="contact-row fax"><i class="fa fa-fax" aria-hidden="true"></i>' . esc_attr( $atts["fax"] ) . '</div>';
				}
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "esport_contact_box", "esport_contact_box_output" );

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__( 'eSport Contact Box', 'esport' ),
			"base" => "esport_contact_box",
			"category" => esc_html__( 'eSport Theme', 'esport' ),
			"icon" => get_template_directory_uri() . '/assets/img/icons/esport-contact-box.jpg',
			"description" =>esc_html__( 'eSport contact box element.', 'esport' ),
			"params" => array(
				array(
					"type" => "textfield",
					"heading" => esc_html__( "Address", 'esport' ),
					"description" => esc_html__( 'You can enter the address.', 'esport' ),
					"param_name" => "address",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( "Email", 'esport' ),
					"description" => esc_html__( 'You can enter the email.', 'esport' ),
					"param_name" => "email",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( "Phone", 'esport' ),
					"description" => esc_html__( 'You can enter the phone.', 'esport' ),
					"param_name" => "phone",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( "Fax", 'esport' ),
					"description" => esc_html__( 'You can enter the fax.', 'esport' ),
					"param_name" => "fax",
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( "Text", 'esport' ),
					"description" => esc_html__( 'You can enter the text.', 'esport' ),
					"param_name" => "abouttext",
				),
			),
		)
		);
	}
	/*------------- ESPORT CONTACT BOX END -------------*/

	/*------------- ESPORT MAILCHIMP NEWSLETTER START -------------*/
	function esport_mailchimp_newsletter_output( $atts, $content = null ) {
		$atts = shortcode_atts(
			array(
				'style' => '',
				'id' => '',
			), $atts
		);
		
		$output = '';

		if( !empty( $atts["id"] ) ) {
			$output = '<div class="esport-newsletter-element ' . esc_attr( $atts["style"] ) . '">';
				$output .= do_shortcode( '[mc4wp_form id="' . esc_attr( $atts["id"] ) . '"]' );
			$output .= '</div>';
		}

		return $output;
	}
	add_shortcode( "esport_mailchimp_newsletter", "esport_mailchimp_newsletter_output" );

	if(function_exists('vc_map')){
		vc_map( array(
			"name" => esc_html__( 'eSport MailChimp Newsletter', 'esport' ),
			"base" => "esport_mailchimp_newsletter",
			"category" => esc_html__( 'eSport Theme', 'esport' ),
			"icon" => get_template_directory_uri() . '/assets/img/icons/esport-mailchimp-newsletter.jpg',
			"description" =>esc_html__( 'eSport mailChimp newsletter element.', 'esport' ),
			"params" => array(
				array(
					"type" => "dropdown",
					"heading" => esc_html__( 'Style', 'esport' ),
					"description" => esc_html__( 'You can select the style.', 'esport' ),
					"param_name" => "style",
					'save_always' => true,
					'value' => array(
						esc_html__( 'Style 1', 'esport' ) => 'style1',
						esc_html__( 'Style 2', 'esport' ) => 'style2',
						esc_html__( 'Style 3', 'esport' ) => 'style3',
					),
				),
				array(
					"type" => "textfield",
					"heading" => esc_html__( 'MailChimp Newsletter ID', 'esport' ),
					"description" => esc_html__( 'You can enter the MailChimp newsletter id.', 'esport' ),
					"param_name" => "id",
				),
			),
		)
		);
	}
	/*------------- ESPORT MAILCHIMP NEWSLETTER END -------------*/
/*--------------- VC ELEMENTS END ---------------*/